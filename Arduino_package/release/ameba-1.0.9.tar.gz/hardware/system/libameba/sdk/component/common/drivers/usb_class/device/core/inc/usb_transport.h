#ifndef _USB_BOT_H
#define _USB_BOT_H
#include "basic_types.h"

#endif