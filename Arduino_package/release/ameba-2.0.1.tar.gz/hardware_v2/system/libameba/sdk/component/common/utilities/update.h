/*

The code in this file has been moved to the following file:
"soc\realtek\8195a\misc\platform\ota_8195a.h".
Please use new file "ota_8195a.h" to replace the previous "update.h" file
and add this path to the project.

*/
