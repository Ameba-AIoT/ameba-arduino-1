#ifndef _UVC_DRV_H_
#define _UVC_DRV_H_

void set_uvc_contex(int frame_type, int width, int height, int frame_rate, int compression_ratio);

#endif
