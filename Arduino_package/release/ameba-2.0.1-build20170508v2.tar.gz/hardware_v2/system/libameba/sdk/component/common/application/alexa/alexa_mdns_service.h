#ifndef _ALEXA_MDNS_SERVICE_H_
#define _ALEXA_MDNS_SERVICE_H_

int init_alexa_mdns_service();
int deinit_alexa_mdns_service();

char *get_alexa_platform_hostname();

#endif